//
//  RaiseIssueModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/10/23.
//

import Foundation

// MARK: - Welcome
struct RaiseIssueModel: Codable {
    let status, message: String
}

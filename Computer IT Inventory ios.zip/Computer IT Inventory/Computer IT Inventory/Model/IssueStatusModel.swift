//
//  IssueStatusModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 11/10/23.
//

import Foundation

// MARK: - Welcome
struct IssueStatusModel: Codable {
    let status: Bool
    let message: String
    let data: [issues]
}

// MARK: - Datum
struct issues: Codable {
    let itemID, isssueDate, status: String

    enum CodingKeys: String, CodingKey {
        case itemID = "Item ID"
        case isssueDate = "Isssue Date"
        case status = "Status"
        
}
}

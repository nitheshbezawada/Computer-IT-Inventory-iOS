//
//  ProfileModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 13/10/23.
//

import Foundation

// MARK: - Welcome
//struct ProfileModel: Codable {
//    var status: Bool?
//    var message: String?
//    var data: [ProfileClass]?
//}
//
//// MARK: - DataClass
//struct ProfileClass: Codable {
//    var id, name, username, password: String?
//    var type, status: String?
//}

// MARK: - ProfileModel
struct ProfileModel: Codable {
    var status: Bool?
    var message: String?
    var data: [ProfileClass]?
}

// MARK: - Datum
struct ProfileClass: Codable {
    var id, name, username, password: String?
    var type, status: String?
}

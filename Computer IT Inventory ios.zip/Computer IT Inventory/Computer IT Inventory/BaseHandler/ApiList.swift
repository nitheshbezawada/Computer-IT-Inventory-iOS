//
//  ApiList.swift
//  Computer IT Inventory
//
//  Created by SAIL on 26/10/23.
//

import Foundation

struct APIList
{
    let BASE_URL = "http://192.168.187.251/Testingapi/"
   
  
    func urlString(url: urlString) -> String
    {
        return BASE_URL + url.rawValue
    }
}

enum urlString: String

{
    case logInGet = "loginGet.php?"
    case getAllData = "getalldata.php"
    case issueStatus = "issuestatus.php"
    case issuestatuscompleted = "issuescompleted.php"
    case managerIssueList = "managerissues.php"
    case techList = "selecttechnician.php"
    case techstatus = "technicianstatus.php"
    case techcompleted = "managercompleted.php"
    case RaiseIssue = "raiseissueget.php"
    case AddUser  = "addusernew.php"
    case EditProfile = "editprofile.php"
  
}

//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit




public class Constants {
    var userId : String? {
        return UserDefaultsManager.shared.getUserAge()
    }
    
    enum serviceType: String {
        case loginAPI = "http://192.168.187.251/Testingapi/loginGet.php?username=admin&password=admin123"
        
        
        static var ProfileAPI : String {
            if let userId = Constants().userId {
                return "http://192.168.187.251/Testingapi/profile.php?id=\(userId)"
            }
            else {
                return ""
            }
        }
        case weatherurl = "https://api.openweathermap.org/data/2.5/weather?lat=35&lon=139&appid=4cd569ffb3ecc3bffe9c0587ff02109f"
        case forecasturl = "https://api.openweathermap.org/data/2.5/onecall?lat=33.44&lon=-94.04&appid=4cd569ffb3ecc3bffe9c0587ff02109f"
        case techListURL = ""
    }
    
    static let loginUrl: serviceType = .loginAPI
    static let forecast: serviceType = .forecasturl
}

//
//  selectTechIssueCell.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class selectTechIssueCell: UITableViewCell {
    @IBOutlet weak var tech: UILabel!
    @IBOutlet weak var techButton: UIButton!
    

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}

//
//  JosAssignTabCell.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class JosAssignTabCell: UITableViewCell {
    @IBOutlet weak var JobID: UILabel!
    @IBOutlet weak var ItemID: UILabel!
    @IBOutlet weak var IssueDate: UILabel!
    @IBOutlet weak var Time: UILabel!
    @IBOutlet weak var completeTimeLabel: UILabel!
    @IBOutlet weak var completeLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

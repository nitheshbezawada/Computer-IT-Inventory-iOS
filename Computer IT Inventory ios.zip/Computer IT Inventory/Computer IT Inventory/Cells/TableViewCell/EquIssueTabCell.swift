//
//  EquIssueTabCell.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class EquIssueTabCell: UITableViewCell {
    
    @IBOutlet weak var ItemIDLabel: UILabel!
    @IBOutlet weak var DateOfRequestLabel: UILabel!
    @IBOutlet weak var completedNameLabel: UILabel!
    @IBOutlet weak var completedListLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

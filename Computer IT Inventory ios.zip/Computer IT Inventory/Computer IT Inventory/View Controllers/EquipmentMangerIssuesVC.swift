//
//  EquipmentMangerIssuesVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class EquipmentMangerIssuesVC: UIViewController {

    @IBOutlet weak var doneButtonOutlet: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var menu: UIImageView!
    @IBOutlet weak var segmentalController: UISegmentedControl!
    
    var issueStatus = [issues]()
    var completedStatus : IssuesCompletedModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
        GetAPI()
        
        menu.addAction(for: .tap) {
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        GetAPI()
    }
    
    @IBAction func segmentAction(_ sender: Any) {
        if segmentalController.selectedSegmentIndex == 0 {
            GetAPI()
            tableView.reloadData()
        } else {
            GetAPI()
            tableView.reloadData()
        }
    }
    
    
    @IBAction func doneButton(_ sender: Any) {
        
        let storyBoard: UIStoryboard =  UIStoryboard(name:"Main", bundle:nil)
     let vc=storyBoard.instantiateViewController(withIdentifier: "HomeViewController")
        as! HomeViewController
        self.navigationController?.pushViewController(vc, animated: true)
          }
    
    
    func GetAPI(){
        if segmentalController.selectedSegmentIndex == 0 {
            let apiURL = APIList().urlString(url:.issueStatus )
            print("apiURL : \(apiURL)")
               APIHandler().getAPIValues(type: IssueStatusModel.self, apiUrl: apiURL, method: "GET") {  result in
          switch result {
          case .success(let datas):
              self.issueStatus = datas.data
              print(datas)
              if datas.status == true{
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
              }
              else if datas.status == false{

              }
              case .failure(let error):
              print(error)
              DispatchQueue.main.async {
              let alert = UIAlertController(title: "Warning", message: "Incorrect Password or ID", preferredStyle: .alert)
              alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                  print("JSON Error")
                 })
                  self.present(alert, animated: true, completion: nil)
                  }
                }
               }
        } else {

            let apiURL = APIList().urlString(url:.issuestatuscompleted )
            print("apiURL : \(apiURL)")
            APIHandler().getAPIValues(type: IssuesCompletedModel.self, apiUrl: apiURL, method: "GET") { [self]  result in
          switch result {
          case .success(let datas):
              self.completedStatus = datas
              print(datas)
              if self.completedStatus?.status == true{
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
              }
              else if self.completedStatus?.status == false{

              }
              case .failure(let error):
              print(error)
              DispatchQueue.main.async {
              let alert = UIAlertController(title: "Warning", message: "Incorrect Password or ID", preferredStyle: .alert)
              alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                  print("JSON Error")
                 })
                  self.present(alert, animated: true, completion: nil)
                  }
                }
               }
        }
        }
        
        
}
    







extension EquipmentMangerIssuesVC : UITableViewDelegate, UITableViewDataSource {
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if segmentalController.selectedSegmentIndex == 0 {
        return issueStatus.count
    } else {
        return completedStatus?.data.count ?? 0
    }
    
}


func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "EquIssueTabCell", for: indexPath) as! EquIssueTabCell
    if segmentalController.selectedSegmentIndex == 0 {
        
    cell.ItemIDLabel.text = issueStatus[indexPath.row].itemID
    cell.DateOfRequestLabel.text = issueStatus[indexPath.row].isssueDate
        cell.completedListLabel.isHidden = true
        cell.completedNameLabel.isHidden = true
        
    }else {
        cell.completedListLabel.isHidden = false
        cell.completedNameLabel.isHidden = false
        cell.ItemIDLabel.text = completedStatus?.data[indexPath.row].itemID
        cell.DateOfRequestLabel.text = completedStatus?.data[indexPath.row].isssueDate
        cell.completedListLabel.text = completedStatus?.data[indexPath.row].dateOfCompletion
    }
    
    return cell
}
func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    if segmentalController.selectedSegmentIndex == 0 {
        return 90
    } else {
        return 120
    }
    
}
func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let vc = self.storyboard?.instantiateViewController(withIdentifier: "EquipmentMangerIssuesVC") as! EquipmentMangerIssuesVC
    self.navigationController?.pushViewController(vc, animated: true)
}
}



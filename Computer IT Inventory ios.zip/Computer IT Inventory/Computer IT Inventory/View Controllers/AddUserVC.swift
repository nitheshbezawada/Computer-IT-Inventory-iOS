//
//  AddUser.swift
//  Computer IT Inventory
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class AddUserVC: UIViewController {
    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var UsernameTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var UsertypeTextField: UITextField!
    

    @IBOutlet weak var adduser: UIButton!
    
    var addUser : AddUserModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        adduser.addAction(for: .tap) {
//            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
//            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
        func AddUserPostAPI(){
        
               let parameters:[String : String] = [
                   "name": NameTextField.text ?? "" , "username":UsernameTextField.text ?? "" , "password":PasswordTextField.text ?? ""]
               APIHandler().postAPIValues(type:AddUserModel.self,apiUrl: APIList().urlString(url: .AddUser), method: "POST", formData: parameters) { Result in
                   switch Result {
                    case .success(let Data):
                        print(Data)
                       DispatchQueue.main.async {
//                           self.adduser.addAction(for: .tap) {
                               let alert = UIAlertController(title: "Success", message: "User added successfully!", preferredStyle: .alert)
                               alert.addAction(UIAlertAction(title: "OK", style: .destructive) { ok in
                                   print("User added")
//                                   let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC")as!ChooselabVC;
//                                   self.navigationController?.pushViewController(nextvc, animated: true)
                                   self.navigationController?.popViewController(animated: true)
                                   
                               })
                               self.present(alert, animated: true, completion: nil)
//                           }
                        }
                   case .failure(let error):
                       print(error)
                    }
                }
            }
      

    
    
    @IBAction func Done(_ sender: Any) {
        if NameTextField.text == "" && UsernameTextField.text == "" && PasswordTextField.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Please enter the values", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .destructive) { ok in
                //                print("User added")
                //                let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC")as!ChooselabVC;
                //                self.navigationController?.pushViewController(nextvc, animated: true)
                
            })
            self.present(alert, animated: true, completion: nil)
        } else {
            AddUserPostAPI()
        }
    }

}

//
//  HomeViewController.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var menu: UIImageView!
    @IBOutlet weak var windows: UIImageView!
    @IBOutlet weak var mac: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if UserDefaults.standard.string(forKey: "ImageName") == "Window" {
            self.navigationController?.isNavigationBarHidden = false

        }
        self.navigationController?.isNavigationBarHidden = true

        windows.addAction(for: .tap) {
            let imageName = "window"
            UserDefaults.standard.set(imageName, forKey: "ImageName")
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SystemDataVC") as! SystemDataVC
        
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        mac.addAction(for: .tap) {
            let imageName = "mac"
            UserDefaults.standard.set(imageName, forKey: "ImageName")
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SystemDataVC") as! SystemDataVC
            
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        menu.addAction(for: .tap) {
          
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }

    @IBAction func nextAc(_ sender: Any) {
    }
    
}

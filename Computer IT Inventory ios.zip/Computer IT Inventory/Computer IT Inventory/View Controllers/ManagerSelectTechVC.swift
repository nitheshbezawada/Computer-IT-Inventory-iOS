//
//  ManagerSelectTechVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class ManagerSelectTechVC: UIViewController {

   
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var menu: UIImageView!
    
    var TechDatas : SelectTechModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        self.TechListAPI()
        
        
        menu.addAction(for: .tap) { [self] in
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
    
    @IBAction func done(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "assignsucess") as! assignsucess
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    @objc func connected(sender: UIButton) {
            if let currentImage = sender.imageView?.image {
                if sender.tintColor == .red { // Check if the button is already red
                    sender.setImage(currentImage, for: .normal) // Revert to the original image
                    sender.tintColor = .systemGray2 // Assuming the default color is black
                } else {
                    let redTintedImage = currentImage.withRenderingMode(.alwaysTemplate)
                    sender.setImage(redTintedImage, for: .normal)
                    sender.tintColor = .red
                }
            }
        }
    
    func TechListAPI(){
        APIHandler().getAPIValues(type: SelectTechModel.self, apiUrl: APIList().urlString(url: .techList), method: "GET") { Result in
            switch Result {
            case .success(let data):
                print(data)
                self.TechDatas = data
                print(self.TechDatas?.data.count ?? 0)
                print(self.TechDatas?.data ?? "")
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    
    
    
}

extension ManagerSelectTechVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TechDatas?.data.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "selectTechIssueCell", for: indexPath) as! selectTechIssueCell
        if let TechData = self.TechDatas?.data, indexPath.row < TechData.count {
            cell.tech.text = TechData[indexPath.row].firstName
        } else {
            cell.tech.text = "No data available"
        }
        cell.techButton.addTarget(self, action: #selector(connected(sender:)), for: .touchUpInside)
        cell.techButton.tag = indexPath.row
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TechJobAssignVC") as! TechJobAssignVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

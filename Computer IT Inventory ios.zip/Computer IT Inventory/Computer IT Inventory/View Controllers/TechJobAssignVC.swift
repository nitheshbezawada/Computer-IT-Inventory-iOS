//
//  TechJobAssignVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class TechJobAssignVC: UIViewController {

    @IBOutlet weak var menu: UIImageView!
    @IBOutlet weak var segmentalController: UISegmentedControl!
    @IBOutlet weak var Tableview: UITableView!{
        didSet{
            Tableview.dataSource = self
            Tableview.delegate = self
        }
    }
    
    var techStatus : TechStatusModel?
    var completedStatus : TechCompletedModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        GetAPI()
        menu.addAction(for: .tap) {
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
    @IBAction func segmentAction(_ sender: UISegmentedControl) {
        if segmentalController.selectedSegmentIndex == 0 {
            GetAPI()
            Tableview.reloadData()
        } else {
            GetAPI()
            Tableview.reloadData()
        }
    }
    func GetAPI(){
        if segmentalController.selectedSegmentIndex == 0 {
        APIHandler().getAPIValues(type: TechStatusModel.self, apiUrl: APIList().urlString(url: .techstatus), method: "GET") { Result in
            switch Result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                self.techStatus = data
                print(self.techStatus?.data.count ?? 0)
                print(self.techStatus?.data ?? "")
                
                    self.Tableview.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
        }
        else{
            APIHandler().getAPIValues(type: TechCompletedModel.self, apiUrl: APIList().urlString(url: .techcompleted), method: "GET") { Result in
                switch Result {
                case .success(let data):
                    print(data)
                    DispatchQueue.main.async {
                    self.completedStatus = data
                    print(self.completedStatus?.data.count ?? 0)
                    print(self.completedStatus?.data ?? "")
                    
                        self.Tableview.reloadData()
                    }
                case .failure(let error):
                    print(error)
                }
            }
            
        }
    }
    

}

extension TechJobAssignVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if segmentalController.selectedSegmentIndex == 0 {
            return techStatus?.data.count ?? 0
        } else {
            return completedStatus?.data.count ?? 0
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JosAssignTabCell", for: indexPath) as! JosAssignTabCell
        if segmentalController.selectedSegmentIndex == 0 {        
        cell.JobID.text     = techStatus?.data[indexPath.row].memberID
        cell.ItemID.text    = techStatus?.data[indexPath.row].itemID
        cell.IssueDate.text = techStatus?.data[indexPath.row].issueDate
        cell.Time.text      = techStatus?.data[indexPath.row].timeLimit
            cell.completeTimeLabel.isHidden = true
            cell.completeLabel.isHidden = true
        }else {
            cell.JobID.text     = completedStatus?.data[indexPath.row].memberID
            cell.ItemID.text    = completedStatus?.data[indexPath.row].itemID
            cell.IssueDate.text = completedStatus?.data[indexPath.row].issueDate
            cell.Time.text      = completedStatus?.data[indexPath.row].timeLimit
            cell.completeTimeLabel.isHidden = false
            cell.completeLabel.isHidden = false
            cell.completeTimeLabel.text = completedStatus?.data[indexPath.row].completedDate
        }
            
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if segmentalController.selectedSegmentIndex == 0 {
            return 130
        } else {
            return 150
        }
    }
    
}




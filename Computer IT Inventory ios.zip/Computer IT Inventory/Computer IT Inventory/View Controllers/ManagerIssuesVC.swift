//
//  ManagerIssuesVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class ManagerIssuesVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var menu: UIImageView!
    
    var issueDatas : ManagerIssueModel? {
        didSet {
            if let issueDatas = issueDatas {
                print("Issue data is available: \(issueDatas)")
            }
            else {
                print("Issue data is nil")
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        self.ManagerIssueListAPI()
        menu.addAction(for: .tap) {
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
    
    @IBAction func done(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    @IBAction func assign(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerSelectTechVC") as! ManagerSelectTechVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    func ManagerIssueListAPI(){
        APIHandler().getAPIValues(type: ManagerIssueModel.self, apiUrl: APIList().urlString(url: .managerIssueList), method: "GET") { Result in
            switch Result {
            case .success(let data):
                print(data)
                self.issueDatas = data
                print(self.issueDatas?.data.count ?? 0)
                print(self.issueDatas?.data ?? "")
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}


extension ManagerIssuesVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return issueDatas?.data.count ?? 2
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EquIssueTabCell", for: indexPath) as! EquIssueTabCell
        if let issuesData = self.issueDatas?.data, indexPath.row < issuesData.count {
            cell.ItemIDLabel.text = issuesData[indexPath.row].itemID
            cell.DateOfRequestLabel.text = issuesData[indexPath.row].isssueDate
        } else {
            cell.ItemIDLabel.text = "No data available"
            cell.DateOfRequestLabel.text = ""
        }
        return cell
    }


}

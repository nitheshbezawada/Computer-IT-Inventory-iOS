//
//  ManagerProfileMenuVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class ManagerProfileMenuVC: UIViewController {

    @IBOutlet weak var adduser: UIImageView!
    @IBOutlet weak var logout: UIImageView!
    @IBOutlet weak var profile: UIImageView!
    @IBOutlet weak var arrow: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        arrow.addAction(for: .tap) {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerIssuesVC") as! ManagerIssuesVC
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
        logout.addAction(for: .tap) {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectUserVC") as! SelectUserVC
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        adduser.addAction(for: .tap) {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddUserVC") as! AddUserVC
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
    }
    @IBAction func profile(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
}

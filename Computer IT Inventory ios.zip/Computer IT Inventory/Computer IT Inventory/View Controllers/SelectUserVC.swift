//
//  SelectUserVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 27/09/23.
//

import UIKit

class SelectUserVC: UIViewController {

    var selectUser : String?
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }

    @IBAction func equipManger(_ sender: Any) {
        self.performSegue(withIdentifier: "equipmanager", sender: nil)
        selectUser = "EquipManager"
        UserDefaults.standard.set(selectUser, forKey: "selectUser")
         
    }
    
    @IBAction func manager(_ sender: Any) {
        self.performSegue(withIdentifier: "manager", sender: nil)
        selectUser = "Manager"
        UserDefaults.standard.set(selectUser, forKey: "selectUser")


    }
    
    
}

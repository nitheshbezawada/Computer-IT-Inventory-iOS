//
//  RaiseIssueVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class RaiseIssueVC: UIViewController {

    @IBOutlet weak var SerialNoTextField: UITextField!
    @IBOutlet weak var IssueDateTextField: UITextField!
    @IBOutlet weak var TimeTextField: UITextField!

    var raiseIssue: RaiseIssueModel!

    lazy var datePicker: UIDatePicker = {
        let picker = UIDatePicker()
        picker.datePickerMode = .date
        picker.addTarget(self, action: #selector(datePickerValueChanged(_:)), for: .valueChanged)
        return picker
    }()

    lazy var timePicker: UIDatePicker = {
        let picker = UIDatePicker()
        picker.datePickerMode = .time
        picker.addTarget(self, action: #selector(timePickerValueChanged(_:)), for: .valueChanged)
        return picker
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupDateAndTimePickers()

        // Set the IssueDateTextField with the current date
        let currentDate = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        IssueDateTextField.text = formatter.string(from: currentDate)

        // Set the TimeTextField with the current time
        formatter.dateFormat = "hh:mm a"
        TimeTextField.text = formatter.string(from: currentDate)
    }

    func setupDateAndTimePickers() {
        IssueDateTextField.inputView = datePicker
        TimeTextField.inputView = timePicker
    }

    @objc func datePickerValueChanged(_ sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        IssueDateTextField.text = formatter.string(from: sender.date)
    }

    @objc func timePickerValueChanged(_ sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        TimeTextField.text = formatter.string(from: sender.date)
    }

    func RaiseIssuePostAPI() {
        let parameters: [String: String] = [
            "item_id": SerialNoTextField.text ?? "",
            "reserve_date": IssueDateTextField.text ?? "",
            "reservation_time": TimeTextField.text ?? ""
        ]

        // Your existing API request code
        APIHandler().postAPIValues(type: RaiseIssueModel.self, apiUrl: APIList().urlString(url: .RaiseIssue), method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    let nextvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SucccesfullyVC") as! SucccesfullyVC
                    self.navigationController?.pushViewController(nextvc, animated: true)
                }
            case .failure(let error):
                print(error)
            }
        }
    }

    @IBAction func submit(_ sender: Any) {
        RaiseIssuePostAPI()
    }
}

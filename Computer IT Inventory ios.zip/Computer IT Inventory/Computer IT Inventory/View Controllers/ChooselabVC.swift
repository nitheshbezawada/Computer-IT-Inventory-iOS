//
//  ChooselabVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class ChooselabVC: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var menu: UIImageView!
    let labName = ["Sail Lab", "iOS Lab", "DBMS Lab", "OS Lab"]

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.collectionViewLayout = UICollectionViewFlowLayout()
    
        menu.addAction(for: .tap) {
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
    
    @IBAction func loginAc(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SystemDataVC") as! SystemDataVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
}

extension ChooselabVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collCell", for: indexPath) as! ChooseLabTabCell
        
        cell.chooseLab.layer.cornerRadius = 10
        cell.chooseLab.layer.borderWidth = 2
        cell.chooseLab.layer.borderColor = UIColor.red.cgColor

        cell.labName.text = labName[indexPath.row]
        
        return cell
    }
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2   //return number of rows in section
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Set the size of each grid item
        let cellWidth = (collectionView.frame.width - 20) / 2 // Adjust as needed
        let cellHeight = 100 // Adjust as needed
        return CGSize(width: cellWidth, height:100)
    }
 
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedItem = labName[indexPath.row]
        print(selectedItem)
        
        if selectedItem == "Sail Lab" {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            let imageName = "Window"
            UserDefaults.standard.set(imageName, forKey: "ImageName")
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        else if selectedItem == "iOS Lab" {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SystemDataVC") as! SystemDataVC
            let imageName = "mac"
            UserDefaults.standard.set(imageName, forKey: "ImageName")
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        else {
            let imageName = "window"
            UserDefaults.standard.set(imageName, forKey: "ImageName")
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SystemDataVC") as! SystemDataVC
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
     
    }
    
    
}

//
//  TotalSystemVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class TotalSystemVC: UIViewController {

    @IBOutlet weak var totalSystemCount: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var menu: UIImageView!
    
   
    var systemDetails = [details]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        GetAPI()
        menu.addAction(for: .tap) {
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
    
    func GetAPI(){
        
        let apiURL = APIList().urlString(url:.getAllData )
        print("apiURL : \(apiURL)")
        APIHandler().getAPIValues(type: SystemDetailsModel.self, apiUrl: apiURL, method: "GET") {  result in
      switch result {
      case .success(let datas):
         
          self.systemDetails = datas.data
          print(datas)
          
          if datas.status == true{
              
              DispatchQueue.main.async {
                  self.totalSystemCount.text = "\(self.systemDetails.count)"
                                      self.tableView.reloadData()
                                  }
          }
          else if datas.status == false{

          }
          case .failure(let error):
          print(error)
          DispatchQueue.main.async {

          let alert = UIAlertController(title: "Warrning", message: "Incorrect Password or ID", preferredStyle: .alert)
          alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
              print("JSON Error")
             })
              self.present(alert, animated: true, completion: nil)
              }
            }
           }
    }

}
extension TotalSystemVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        systemDetails.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TotalSysTableCell", for: indexPath) as! TotalSysTableCell
        cell.modelLabel.text = systemDetails[indexPath.row].model
        cell.categoryLabel.text = systemDetails[indexPath.row].category
        cell.brandLabel.text = systemDetails[indexPath.row].brand
        let ImageName = UserDefaults.standard.string(forKey: "ImageName") ?? ""
        cell.sysImage.image =  UIImage(named: ImageName)
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SystemDetailsVC") as! SystemDetailsVC
        vc.detailsSystem = systemDetails[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
    
    
    
    
    
//
//    var apiURL = ""
//    var totalSystem = [detail]()
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        tableView.delegate = self
//        tableView.dataSource = self
//        menu.addAction(for: .tap) {
//            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
//            self.navigationController?.pushViewController(nextVC, animated: true)
//        }
//    }
//
//    override func viewWillAppear(_ animated: Bool) {
//        GetAPI()
//    }
//    @IBAction func doneAc(_ sender: Any) {
//
//
//        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SystemDetailsVC") as! SystemDetailsVC
//        self.navigationController?.pushViewController(nextVC, animated: true)
//    }
//    func GetAPI(){
//       let  apiURL = "http://192.168.26.251/Testingapi/items.php"
//           APIHandler().getAPIValues(type: TotalSystemModel.self, apiUrl: apiURL, method: "GET") {  result in
//               switch result {
//               case .success(let datas):
//                   self.totalSystem = datas.data
//
//
//                   print(datas)
//
//                   if datas.status == true{
//
//                       DispatchQueue.main.async {
//                    self.tableView.reloadData()
//                                           }
//                   }
//                   else if datas.status == false{
//
//                   }
//                   case .failure(let error):
//                   print(error)
//                   DispatchQueue.main.async {
//
//                   let alert = UIAlertController(title: "Warrning", message: "Incorrect Password or ID", preferredStyle: .alert)
//                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
//                       print("JSON Error")
//
//                   })
//                   self.present(alert, animated: true, completion: nil)
//                   }
//               }
//       }
//
//            }
//
//}
//
//
//extension TotalSystemVC : UITableViewDelegate, UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        systemDetails.count
//    }
//
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "TotalSysTableCell", for: indexPath) as! TotalSysTableCell
//        let imageName = UserDefaults.standard.string(forKey: "ImageName")
//        let selectUser =  UserDefaults.standard.string(forKey: "selectUser")
//
//         if selectUser == "EquipManager" {
//             cell.sysImage.image = UIImage(named: imageName ?? "")
//         }
//         else if selectUser == "Manager" {
//             cell.sysImage.image = UIImage(named: imageName ?? "")
//         }
//
//
//        return cell
//    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "TotalSysTableCell", for: indexPath) as! TotalSysTableCell
//        let imageName = UserDefaults.standard.string(forKey: "ImageName")
//        let selectUser =  UserDefaults.standard.string(forKey: "selectUser")
//         if selectUser == "EquipManager" {
//             cell.sysImage.image = UIImage(named: imageName ?? "")
//             let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
//             self.navigationController?.pushViewController(nextVC, animated: true)
//         }
//         else if selectUser == "Manager" {
//             cell.sysImage.image = UIImage(named: imageName ?? "")
//             let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
//             self.navigationController?.pushViewController(nextVC, animated: true)
//         }
//    }
//
//
//
//}





//extension TotalSystemVC : UITableViewDelegate, UITableViewDataSource {
//func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//    totalSystem.count
//}
//
//
//func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//    let cell = tableView.dequeueReusableCell(withIdentifier: "SysDetailsCell", for: indexPath) as! SysDetailsCell
//    cell.modelLabel.text = totalSystem[indexPath.row].model
//    cell.categoryLabel.text = totalSystem[indexPath.row].category
//    cell.brandLabel.text = totalSystem[indexPath.row].brand
//   // cell.quantityLabel.text = systemDetails[indexPath.row].quantity
//   // cell.statusLabel.text = systemDetails[indexPath.row].status
//   // cell.priceLabel.text = systemDetails[indexPath.row].price
//
//    return cell
//}
//func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//    return 150
//}
//}

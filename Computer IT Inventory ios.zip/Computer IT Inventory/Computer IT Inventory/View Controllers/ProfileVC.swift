//
//  ProfileVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class ProfileVC: UIViewController {
   

    @IBOutlet weak var Namelbl: UILabel!
    @IBOutlet weak var Usernamelbl: UILabel!
    @IBOutlet weak var Usertypelbl: UILabel!
    let apiHandler : APIHandler = APIHandler()
    var apiData : ProfileModel!
    var apiUrl = String()
    override func viewDidLoad() {
        super.viewDidLoad()

       
    
}
override func viewWillAppear(_ animated: Bool) {
    GetAPI()

}

    @IBAction func Edit(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EditProfileVC") as! EditProfileVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    func GetAPI(){
    
    apiHandler.getAPIValues(type: ProfileModel.self, apiUrl: Constants.serviceType.ProfileAPI, method: "GET") { [self] result in
        switch result {
        case .success(let data):
            self.apiData = data
            print(data)
            DispatchQueue.main.async {
                self.Namelbl.text = self.apiData.data?.first?.name
                self.Usernamelbl.text = self.apiData.data?.first?.username
                self.Usertypelbl.text = self.apiData.data?.first?.type
                
            }
            
            
        case .failure(let error):
            print(error)
            
        }
    }
    
}
}
